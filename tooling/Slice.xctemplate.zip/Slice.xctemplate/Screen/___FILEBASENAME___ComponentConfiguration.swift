//
//  ___VARIABLE_productName___ComponentConfiguration.swift
//
//
//  Created by Rodrigo Borges Soares on 23/08/19.
//  Copyright © 2019 CocoaPods. All rights reserved.
//

import Foundation

struct ___VARIABLE_productName___ComponentConfiguration {
    
}
